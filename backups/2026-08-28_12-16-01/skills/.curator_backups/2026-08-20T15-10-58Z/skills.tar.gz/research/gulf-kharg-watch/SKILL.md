---
name: gulf-kharg-watch
description: "Use when generating Gulf/Iran situational awareness reports."
version: 1.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [osint, iran, persian-gulf, strait-of-hormuz, kharg-island, situational-awareness, geoint, social-media, ugc, signal-validation]
    related_skills: [arxiv, youtube-content, xurl]
---

# Gulf-Kharg Watch — Situational Awareness Reporter

## Overview

This skill produces open-source intelligence (OSINT) situational awareness reports covering **all of Iran and the broader regional and international environment affecting it**. The report is comprehensive — it covers Iran's provinces, Israel, Gaza, Lebanon, Syria, Iraq, Yemen, the US and its allies, Gulf states, Turkey, Pakistan, Jordan, Egypt, Russia, China, the EU, the UN, and developments in the Red Sea, Bab el-Mandeb, the Persian Gulf, the Strait of Hormuz, and the Gulf of Oman.

**Kharg Island and southern Iran are ONE limited section at the end of the report, not the filter for all content.**

**Language:** All output is in Persian (Farsi) with exact Gregorian and Jalali dates and timestamps.

## When to Use

- User asks for a Gulf/Iran situational awareness report
- User asks about Kharg Island, Strait of Hormuz, or southern Iran developments
- User asks about US/Israeli military posture in the region
- User asks about Gulf state diplomatic or military moves related to Iran
- User wants a regional threat assessment or scenario analysis
- User asks to monitor social media for Gulf/Iran developments
- User asks to validate a specific social media post or claim
- User asks about trending topics related to Kharg, Hormuz, or southern Iran
- User wants to check if a piece of media is old/recycled

**Do NOT use for:**
- Tactical military planning or targeting
- Real-time operational intelligence
- Classified or non-public information
- Predictions of specific attack timelines as certainties

## Social Signal Validation Module

This skill includes a standalone module for monitoring and validating social media signals. Load `references/social-signal-validation.md` for the full module documentation.

**Key features:**
- Fast-sensor layer for event detection via social media and UGC
- Signal status lifecycle: S0 (received) → S1 (single-source) → S2 (multi-report) → S3 (credible evidence) → S4 (confirmed) / SX (rejected)
- **Three-dimensional classification**: Importance (پایین/متوسط/بالا/حیاتی) × Urgency (عادی/نیازمند پیگیری/فوری/بسیار فوری) × Verification (تأییدنشده/شواهد اولیه/چندمنبعی/نسبتاً تأییدشده/تأییدشده)
- **Signal lifecycle**: New → Monitoring → Strengthened → Weakened → Confirmed → Rejected → Unresolved
- Strict rules preventing reposts from being counted as independent witnesses
- Provenance chain tracking and media authenticity validation
- Social signal intensity index (عادی → افزایش محدود → افزایش محسوس → جهش غیرعادی)

**Critical principle:** "تأییدنشده" means verification status, NOT importance. An unverified signal can be Importance=حیاتی and Urgency=بسیار فوری. Never dismiss or delay reporting an important signal just because it lacks official confirmation.

**Source tracking:** Use `references/source-ledger-template.md` to maintain per-account credibility records.

**Web source registry:** Use `references/south-iran-web-source-registry.md` for official, professional, and specialized web sources in southern Iran.

**Telegram source registry:** Use `references/telegram-source-registry.md` for Telegram public channels, and `references/south-iran-telegram-sources.md` for local Telegram sources.

**Integration with reports:** The report template includes a dedicated section "سیگنال‌های سریع شبکه‌های اجتماعی" for social signal analysis.

**Daily reporting:** A cron job runs daily at 08:00 IRST (Asia/Tehran) to generate situational awareness reports. Reports are saved to `/data/.hermes/reports/gulf-kharg-watch/`. Only the last 7 reports are kept.

**Manual access commands:**
- "آخرین گزارش" — Displays the latest saved report without generating a new one.
- "گزارش جدید" — Generates a new report immediately without changing the cron schedule.

## Manual Report Execution Workflow — MANDATORY

### Manual Triggers
- "گزارش جدید" generates and delivers a new full report.
- "گزارش کامل جدید" is the canonical alias for "گزارش جدید".
- "آخرین گزارش" only displays the latest saved report.
- "گزارش کامل" alone is not a defined trigger.

### Default Reporting Window
Use a rolling 24-hour window ending at request start time in Asia/Tehran, unless the user requests another period. State exact Gregorian and Jalali start/end timestamps. Older events are background only.

### End-to-End Workflow
For a manual new-report trigger, complete all stages in the SAME agent turn:
1. Record the reporting window.
2. Load references/report-template.md and required source registries.
3. Collect fresh data and record success, failure, timeout, or missing data for each attempted source.
4. Classify, cross-reference, confidence-score, contextualize, and deduplicate results.
5. Generate all 15 mandatory report sections and validate the final checklist.
6. Save under /data/.hermes/reports/gulf-kharg-watch/ using the existing naming convention.
7. Update latest.md only after successful generation.
8. Return the complete report to the originating Telegram conversation.

### Mandatory Completion Rules
- Never ask the user to send "continue", "next", or another follow-up.
- Never end the turn with only a progress message.
- If non-terminal progress delivery is unavailable, suppress progress and continue.
- Continue the agent/tool loop until completion or explicit terminal failure.
- Wait for every required subtask before producing the final response.
- A failed source must not stop the report; list all unavailable, failed, timed-out, or incomplete sources.
- If full completion is impossible, deliver a clearly labeled partial report with the exact failure reason.
- The final response must contain the report, not only a status, summary, or file path.
- Do not run, retry, modify, or reschedule gulf-kharg-watch-daily.

## Source Classification System

Every piece of information MUST be tagged with one of four categories:

| Category | Persian Label | Definition |
|----------|--------------|------------|
| Confirmed | خبر تأییدشده | Independently verified by 2+ credible sources or official statements |
| Unverified Claim | ادعای تأییدنشده | Single-source or official claim not yet independently confirmed |
| Rumor | شایعه | Unverified social media, anonymous, or low-credibility origin |
| Analysis | تحلیل / ارزیابی | Agent's inference, explicitly labeled as assessment |

### Confidence Scoring

Each claim receives a confidence score (0–100):

| Range | Label | Meaning |
|-------|-------|---------|
| 80–100 | High | Multiple independent confirmations, official sources |
| 50–79 | Moderate | Some corroboration, or single credible official source |
| 20–49 | Low | Single unconfirmed source, circumstantial evidence |
| 0–19 | Very Low | Anonymous, rumor, or single weak source |

### Source Attribution Requirements

For every claim, record:
- **Primary source** — original publisher (name, URL if available)
- **Publication time** — when the source published
- **Confirming source(s)** — independent corroboration (if any)
- **Confidence score** — 0–100

## Information Integrity Rules

1. **Single-source rule:** Never declare a single-source report as confirmed. Tag it as unverified claim.
2. **Event time ≠ publication time:** Record the actual event time separately from when the news was published. If unknown, mark as "زمان وقوع نامشخص".
3. **No recycling:** Do not present old, recycled, or geographically misplaced events as new developments. Cross-check dates and locations.
4. **Explicit labeling:** All analysis and inference MUST carry the label **«ارزیابی»** (assessment). Never blend analysis with confirmed facts.
5. **No certainty in predictions:** Never state an attack will happen. Only present scenarios, indicators, and probability ranges.
6. **No operational intelligence:** Do not generate live coordinates of forces, targeting data, vulnerability assessments, or operational recommendations.
7. **Civilian-safe advice only:** Recommendations limited to public safety awareness and monitoring official advisories.

## Media Handling Rules

### Storage Environment

- **Persistent volume:** `/data` mounted on `/dev/zd1152` (ext4)
- **Temp paths:** `/tmp`, `/var/tmp` on overlay — NOT part of persistent volume capacity
- **Never report overlay free space as Hermes capacity**

### Pre-Processing Checks (mandatory)

Before any download or media processing, verify:

| Check | Command | Rule |
|-------|---------|------|
| Free space on `/data` | `df -h /data` | Must have ≥150 MB free **after** processing |
| Usage percentage on `/data` | `df -h /data` | See status thresholds below |
| Estimated input file size | HTTP headers or metadata | — |
| Estimated temp space needed | 1× for images, 3× for video | — |

**Decision rule:** If multiple conditions are met simultaneously, the **most severe** status applies.

### Status Thresholds

| `/data` Free Space | `/data` Usage | Status | Allowed Actions |
|-------------------|---------------|--------|-----------------|
| ≥200 MB | <80% | ✅ Normal | Media processing allowed (if ≥150 MB remains after) |
| <200 MB but ≥100 MB | ≥80% but <90% | ⚠️ Warning | No media downloads; text/URL/metadata/transcript only |
| <100 MB | ≥90% | 🔴 Critical | All media processing halted; no cache/transcript/temp on `/data`; essential logs only |

**Critical note:** 150 MB is NOT a status threshold. It is the **minimum reserve** that must remain on `/data` after any processing completes. If the estimate shows <150 MB would remain, do not start the processing.

### During Processing

1. **Max direct download: 20 MB** — valid only if `/data` has sufficient free space.
2. **Video processing:** Estimate required space as 3× the input file size.
3. **Audio/transcript extraction:** Account for intermediate files in capacity calculation.
4. **Prefer temp location outside `/data`:** Use `/tmp/hermes-media-tmp/` for processing files.

### After Processing (mandatory report)

For every media processing run, report:

- Free space on `/data` (before and after)
- Usage percentage on `/data` (before and after)
- Free space on temp path
- Size of temp files created
- Cleanup result (success/failure)

### Cleanup Rules

1. Delete: original file, temporary frames, extracted audio, cache entries.
2. Retain ONLY: URL, hash, essential metadata, observation summary, review result.
3. **If cleanup fails:** Halt next media processing. Report file path and size (no sensitive content).
4. **No permanent media archive on `/data`.**
5. **Files >20 MB:** Use metadata, thumbnail, description, online transcript, or low-res version only.

## Report Structure

Generate reports using the template in `references/report-template.md`. The mandatory sections are:

1. **خلاصه اجرایی** — Executive summary (3–5 sentences)
2. **⚠️ هشدارهای سریع و سیگنال‌های حساس** — Fast alerts & sensitive signals (max 10, including unverified)
3. **وضعیت کلی** — Overall status: 🟢 سبز / 🟡 زرد / 🟠 نارنجی / 🔴 قرمز
4. **رویدادهای تأییدشده** — Confirmed events with sources
5. **ادعاهای در حال بررسی** — Unverified claims under review
6. **وضعیت ایران** — Iran domestic situation (all provinces)
7. **وضعیت منطقه‌ای** — Regional situation (Israel, Gaza, Lebanon, Syria, Iraq, Yemen, Gulf states, etc.)
8. **وضعیت تنگه هرمز و کشتیرانی** — Strait of Hormuz & shipping status
9. **شاخص‌های هشدار زودهنگام** — Early warning indicators
10. **سناریوهای 24 تا 72 ساعت آینده** — 24–72 hour scenarios (labeled «ارزیابی»)
11. **تغییردهنده‌های ارزیابی** — What could change this assessment
12. **اقدامات عمومی پیشنهادی** — Civilian recommendations
13. **سیگنال‌های سریع شبکه‌های اجتماعی** — Social media fast-sensor signals (with lifecycle status)
14. **پیامدهای احتمالی برای خارک، صادرات نفت و کار اقماری** — Kharg-specific impact analysis (max 10% of report)
15. **فهرست منابع و سطح اطمینان** — Source list with confidence levels

### هشدارهای سریع و سیگنال‌های حساس (Section 2 — MANDATORY)

This section appears immediately after the executive summary. It displays up to 10 important signals, **even if unverified**. For each signal:

- Signal ID, short title, first seen time, last update time
- General area, platform, account/source, direct URL
- Direct witness or repost
- Detailed description of observation or claim
- Evidence type: text, image, video, audio, multiple witnesses, other public data
- Was the original media viewed? Or only caption/thumbnail?
- Number of publications, number of truly independent origins
- Importance (پایین/متوسط/بالا/حیاتی)
- Urgency (عادی/نیازمند پیگیری/فوری/بسیار فوری)
- Verification (تأییدنشده/شواهد اولیه/چندمنبعی/نسبتاً تأییدشده/تأییدشده)
- Signal status S0–S4 or SX
- Supporting evidence, contradicting evidence, alternative explanations
- Probable impact, next analytical step, suggested review time

**A signal MUST appear in this section if it meets ANY of:**
- Simultaneous observation by multiple independent witnesses
- Fresh image/video with checkable time/location markers
- Report of explosion, launch, attack, or widespread disruption
- Potential link to critical infrastructure
- Sudden disruption in flights, ports, internet, power, or communications
- Local emergency notice
- Sudden change in official positions
- Simultaneous increase in reports from multiple regions
- Potential national or regional impact

### Status Color Definitions

| Color | Persian | Meaning |
|-------|---------|---------|
| 🟢 Green | سبز | Normal, no elevated activity |
| 🟡 Yellow | زرد | Elevated rhetoric or minor incidents |
| 🟠 Orange | نارنجی | Significant incidents, force movements, or diplomatic escalation |
| 🔴 Red | قرمز | Active hostilities, imminent threat, or critical incident |

## Comprehensive Geographic & Topic Scope

**This report covers ALL of Iran and the complete regional and international environment affecting it.** No important national or regional event should be excluded merely because it lacks a direct connection to Kharg Island or southern Iran.

### Scope includes (non-exhaustive):
- All Iranian provinces and regions
- Israel, Gaza, and Palestinian groups
- Lebanon and Hezbollah
- Syria
- Iraq and armed groups
- Yemen and Houthis
- The US and its allies
- Gulf states (Saudi Arabia, UAE, Qatar, Bahrain, Kuwait, Oman)
- Turkey, Pakistan, Jordan, Egypt
- Russia, China, EU, UN and international bodies
- Red Sea, Bab el-Mandeb, Persian Gulf, Strait of Hormuz, Gulf of Oman

### Kharg section rules:
- Kharg Island is covered in ONE limited section at the end: "پیامدهای احتمالی برای خارک، صادرات نفت و کار اقماری"
- This section is DERIVED from the full national/regional analysis, not the filter for all content
- Kharg section typically should not exceed 10% of the total report unless a direct event occurs there
- All events in the report should NOT be attributed to Kharg
- Connection to Kharg is NOT a condition for event inclusion
- The Kharg section may include: oil export impact, shipping security changes, travel disruption, flight/port status, insurance risk changes, public service disruption, local notices, restriction/closure probabilities, strategic-level pressure/siege/attack analysis (with supporting/contradicting evidence), personal safety and preparedness

## Collection Methodology

### Primary Source Categories

| Source Type | Examples | Use For |
|-------------|----------|---------|
| Official government statements | White House, IRGC, MoD releases | Confirmed events |
| Wire services | Reuters, AP, AFP, IRNA, ISNA | Breaking news |
| Maritime tracking | MarineTraffic, VesselFinder, Lloyd's | Shipping & naval movements |
| Aviation tracking | Flightradar24, ADS-B Exchange | Air activity |
| Think tanks | IISS, Chatham House, CSIS | Analysis & context |
| Local/regional media | Tehran Times, Al Jazeera, Al Arabiya | Regional perspective |
| Social media (verified) | Verified journalist accounts, geolocated posts | Ground-truthing |

### Verification Workflow

1. **Identify** — Find the initial report from any source type
2. **Classify** — Tag as confirmed / unverified / rumor / analysis
3. **Cross-reference** — Check against 1+ independent source
4. **Score** — Assign confidence 0–100
5. **Contextualize** — Add historical and geographic context
6. **Report** — Use template structure, Persian language, exact timestamps

## Common Pitfalls

1. **Conflating exercise reports with real operations** — Many Gulf military reports are scheduled exercises. Always check official exercise calendars before reporting as operational.
2. **Satellite imagery misattribution** — Old imagery recirculated as current. Always verify image capture date.
3. **Social media echo chambers** — A single claim amplified by many accounts is still single-source. Count independent origins, not reposts.
4. **Translation errors** — Persian/Arabic/English source material may lose nuance in translation. Flag when relying on translated content.
5. **Confirmation bias** — Actively seek disconfirming evidence. If a threat indicator appears, also check for evidence it's benign.
6. **Recency bias** — Don't over-weight the latest report. Context from days or weeks prior may change the picture.

## Signal Analysis Rules (Launches, Explosions, Military Activity)

1. Eyewitness and public image reports must be registered quickly.
2. Distinguish between: "observed light/trail in sky" → "claimed launch" → "system type confirmed" → "origin" → "path" → "target"
3. Do NOT conclude missile type, precise origin, or certain target from a single light trail observation.
4. Reports on general direction, approximate time, and approximate number of observations ARE registrable.
5. Do NOT provide precise coordinates, live operational paths, operational trajectory predictions, exact launch system locations, targeting data, or any data with operational utility.
6. Origin claims at general level with clear labels only, unless official source or very strong evidence exists.
7. If multiple independent observations from different areas exist, cluster them and analyze probable connection WITHOUT claiming certainty.

## Signal Update Cycle

Every sensitive signal must be trackable through these states:
- **New** — Just received, not yet reviewed
- **Monitoring** — Under active observation
- **Strengthened** — Evidence has improved since last check
- **Weakened** — Evidence has degraded
- **Confirmed** — Verified by official/independent sources
- **Rejected** — Identified as false, recycled, or misplaced
- **Unresolved** — Cannot confirm or deny with available evidence

In each subsequent report, clearly state:
- Which signals were upgraded
- Which signals were downgraded
- Which signals were confirmed
- Which signals were rejected
- Which signals remain unresolved

## Co-Source Detection Rules

- Ten channels reposting one video = NOT ten independent witnesses
- Cropped versions or different logos of same video = one cluster
- One news agency quoted by multiple outlets ≠ multiple confirmations
- Accounts that only copy from one main channel belong to same cluster
- Witnesses with independent angle, time, location, or narrative = registered separately

## Media Analysis Rules

- Existence of image/video does NOT prove the claim
- Upload time ≠ occurrence time
- Check for old/recycled content
- Check general location and time markers
- Check lighting, weather, language, signs, architecture, sounds, general context
- Register visible contradictions
- If original media inaccessible, state: "اصل فایل بررسی نشده و ارزیابی فقط بر اساس متن، thumbnail یا metadata است."

## Verification Checklist

- [ ] All claims classified into one of four categories
- [ ] Every claim has primary source, publication time, and confidence score
- [ ] No single-source reports presented as confirmed
- [ ] Event time distinguished from publication time
- [ ] Analysis sections labeled «ارزیابی»
- [ ] No operational coordinates or targeting data included
- [ ] All predictions framed as scenarios with probability, not certainties
- [ ] Report is in Persian with exact dates and timestamps
- [ ] Media files cleaned up after processing
- [ ] Disk space checked before any download
- [ ] **هشدارهای سریع** section present immediately after executive summary
- [ ] **Unverified but important signals** included in fast alerts (not hidden at end)
- [ ] Each fast-alert signal has: Importance, Urgency, Verification (three separate dimensions)
- [ ] Signal lifecycle status (New/Monitoring/Strengthened/Weakened/Confirmed/Rejected/Unresolved) tracked
- [ ] Kharg section is ≤10% of report and DERIVED from full analysis
- [ ] Report covers ALL of Iran and regional/international environment
- [ ] No event excluded solely due to lack of direct Kharg connection
- [ ] Co-source detection applied (reposts ≠ independent witnesses)
- [ ] Media analysis rules applied (upload time ≠ occurrence time, check for recycled content)
